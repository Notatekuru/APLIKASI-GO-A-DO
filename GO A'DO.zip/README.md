# 🕌 GO A'DO - SuperApp Khidmah & Santri On-Demand

**GO A'DO** adalah aplikasi berbasis Python yang dirancang khusus untuk memecahkan segala problematika kehidupan santri, asrama, dan kobong/kamar pesantren. Dilengkapi dengan **Sistem Gacha Kocokan A'do**, **Fitur Ulasan Berbasis Bintang 1–5**, dan **14 Layanan Khusus Santri**.

---

## 🚀 Cara Menjalankan Aplikasi

Pastikan Python telah terpasang di komputer Anda, lalu buka terminal atau Command Prompt dan jalankan:

```bash
cd C:\Users\clist\.gemini\antigravity\scratch\go-ado
python run.py
```
*(Browser akan otomatis terbuka menampilkan aplikasi di `http://127.0.0.1:5000`)*

Atau bisa juga langsung:
```bash
python app.py
```

---

## 🎯 Fitur Utama

### 1. 🎲 Sistem Gacha Memilih Orang (A'do)
Untuk menghindari perdebatan siapa yang harus piket atau mengemban tugas, sistem menggunakan sistem kocokan gacha berbasis takdir:
- **Tingkat Kelangkaan (Rarity Tier):**
  - **UR (Ultra Rare - 6%)**: *Kang Lurah / Pengurus Sepuh* (Kekuasaan mutlak, tugas beres seketika!).
  - **SSR (Super Super Rare - 22%)**: *Sepuh Penyelamat Jemuran & Master Seduhan* (Cepat, cekatan, amanah 100%).
  - **SR (Super Rare - 35%)**: *Chef Kuliner Malam & Komandan Tandzif* (Bisa diandalkan, rajin).
  - **R (Rare - 24%)**: *Peminjam Handal & Kang Pelor (Nempel Molor)* (Santai, harus digedor dulu).
  - **N (Normal - 13%)**: *A'do Baru Junior* (Nurut 100% tanpa bantah).
- **Animasi & Suara:** Cutscene interaktif dengan suara gacha Web Audio API, efek kartu bersinar, dan dialog santri autentik.
- Pilihan: **Single Pull (1x)** atau **Multi Pull (5x)**.

---

### 2. ⭐ Fitur Ulasan Berbasis Bintang (Bintang 1 – 5)
Setiap tugas yang selesai dapat diberikan penilaian transparan:
- **Pilihan Bintang 1 sampai 5:**
  - ⭐ *(Kurang Barokah - Butuh Introspeksi)*
  - ⭐⭐ *(Butuh Istighfar & Perbaikan)*
  - ⭐⭐⭐ *(Alhamdulillah - Lumayan Baik)*
  - ⭐⭐⭐⭐ *(Mantap Jiwa - Sangat Membantu)*
  - ⭐⭐⭐⭐⭐ *(Masya Allah Tabarakallah - Istimewa & Barokah!)*
- **Komentar & Tag Apresiasi Santri:** `#Barokah`, `#Cepat`, `#Amanah 100%`, `#Anti Cepu`, `#Rapi`, `#Sami'na Wa A'to'na`.
- Penghitungan otomatis rating rata-rata setiap A'do dan leaderboard santri teladan.

---

### 3. ♨️ 14 Layanan Lengkap Santri

1. **Air Panas**: Antri dispenser atau masak air termos di dapur pondok untuk seduhan malam & kompres.
2. **Angkat Cucian**: Evakuasi jemuran sarung, gamis, dan pakaian santri di kawat lantai 3 saat mendung/hujan.
3. **Ambil Nasi**: Ambil jatah talam makan dapur santri, bawa baskom ke kamar, bagi rata antar anggota.
4. **Beli Idam**: Berburu lauk pelengkap di warung luar (oseng tempe, tongkol balado, telur dadar, sayur sop).
5. **Nitip Makanan**: Jastip makanan kantin pondok, pos satpam, atau warung sekitar (gorengan, martabak, seblak).
6. **Tandzif**: Operasi ro'an kebersihan kobong/kamar (nyapu, ngepel wangi, buang sampah ke TPA, rapikan rak kitab).
7. **Manggil Orang**: Panggil dan gedor kamar kawan yang dicari, bangunkan kang molor, panggil piket.
8. **Bawa Barang**: Bantuan angkut galon air isi ulang, koper santri baru, kardus kiriman, perabotan lemari.
9. **Nitip Barang BN**: Ambil & amankan titipan paket di pos Baitun Maal / pos satpam agar tidak kena razia keamanan.
10. **Anti Cepu**: Mode operasi rahasia, jalur steril dari pengurus keamanan, proteksi kerahasiaan jastip.
11. **Minjem Baju**: Peminjaman sarung BHS/Wadimor licin, kemeja koko putih, peci hitam, atau jas muhadhoroh.
12. **Sami'na Wa A'to'na**: Mode instruksi mutlak Rois Kamar / Lurah Pondok. A'do terpilih **WAJIB** laksanakan tanpa menolak (Auto-Accepted 100%).
13. **Minta Mie**: Misi darurat masak/seduh Indomie rebus/goreng tengah malam + telur setengah matang & cabe rawit.
14. **Minta Seduhan**: Racikan minuman pelepas kantuk (kopi hitam tubruk berbusa, good day carribean, teh poci melati, susu jahe hangat).

---

### 4. 🚨 Tombol Darurat "ANTI CEPU" (Panic Button)
Tekan tombol **PANIC BUTTON (ANTI CEPU)** atau tekan tombol keyboard **`ESC` / `F2`** kapan saja!
Layar akan seketika tersamar menjadi halaman kajian kitab kuning **Fathul Qorib Fasal Thaharah & Air Mutlak** lengkap dengan teks Arab dan jadwal ro'an resmi pondok, sehingga aman saat ada ustadz atau bagian keamanan yang melintas!

---

## 📁 Struktur Direktori

```
go-ado/
├── app.py                # Server Flask & REST API
├── run.py                # Launcher otomatis buka browser
├── README.md             # Dokumentasi lengkap
├── data/
│   ├── members.json      # Roster A'do, kelangkaan, rating & stats
│   ├── orders.json       # Database riwayat pesanan khidmah
│   └── reviews.json      # Database ulasan & bintang 1-5
├── templates/
│   └── index.html        # Halaman utama SuperApp GO A'DO
└── static/
    ├── css/
    │   └── style.css     # Animasi gacha, bintang bersinar & styling
    └── js/
        └── app.js        # Logika interaktif, Web Audio SFX & event handler
```
