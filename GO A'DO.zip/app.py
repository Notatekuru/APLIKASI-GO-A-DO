import json
import os
import random
from datetime import datetime
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

MEMBERS_FILE = os.path.join(DATA_DIR, "members.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")
REVIEWS_FILE = os.path.join(DATA_DIR, "reviews.json")

# 14 Layanan Khusus Santri GO A'DO
SERVICES = [
    {
        "id": "air_panas",
        "name": "Air Panas",
        "category": "Kebutuhan Pokok",
        "badge": "Dispenser & Dapur",
        "icon": "fa-mug-hot",
        "color": "from-amber-500 to-red-500",
        "desc": "Antri dispenser lantai bawah / masak air termos di dapur pondok untuk seduhan malam atau kompres.",
        "default_notes": "Refill termos 1 liter, air mendidih 100°C buat kopi & pop mie."
    },
    {
        "id": "angkat_cucian",
        "name": "Angkat Cucian",
        "category": "Logistik Santri",
        "badge": "Anti Kehujanan",
        "icon": "fa-shirt",
        "color": "from-sky-500 to-blue-600",
        "desc": "Evakuasi jemuran sarung, gamis & baju santri di kawat lantai 3 saat mendung atau sudah kering.",
        "default_notes": "Jemuran di tali barat lantai 3, tolong angkat dan lipat rapi."
    },
    {
        "id": "ambil_nasi",
        "name": "Ambil Nasi",
        "category": "Konsumsi",
        "badge": "Talam & Dapur",
        "icon": "fa-bowl-rice",
        "color": "from-yellow-500 to-amber-600",
        "desc": "Ambil jatah talam makan dapur santri, bawa baskom nasi ke kamar, bagi rata antar a'do.",
        "default_notes": "Ambil talam makan siang untuk kamar, jangan lupa minta kerak nasi renyah."
    },
    {
        "id": "beli_idam",
        "name": "Beli Idam",
        "category": "Konsumsi",
        "badge": "Lauk & Sayur",
        "icon": "fa-drumstick-bite",
        "color": "from-orange-500 to-amber-700",
        "desc": "Beli lauk pelengkap di warung luar: tempe orek, telur balado, tongkol suwir, sayur sop, sambal terasi.",
        "default_notes": "Beli telur dadar + oseng tempe basah di Warung Mpok, budget 10rb."
    },
    {
        "id": "nitip_makanan",
        "name": "Nitip Makanan",
        "category": "Jastip Santri",
        "badge": "Kantin & Luar",
        "icon": "fa-utensils",
        "color": "from-emerald-500 to-teal-700",
        "desc": "Jastip makanan dari kantin pondok, pos satpam, atau warung sekitar: seblak, martabak, gorengan hangat.",
        "default_notes": "Nitip gorengan bakwan 5 biji + tahu isi 5 biji cabe rawit banyak."
    },
    {
        "id": "tandzif",
        "name": "Tandzif",
        "category": "Kebersihan",
        "badge": "Ro'an Kamar",
        "icon": "fa-broom",
        "color": "from-teal-500 to-emerald-600",
        "desc": "Piket ro'an kebersihan kobong/kamar: sapu lantai, pel wangi, buang sampah ke TPA, rapikan lemari kitab.",
        "default_notes": "Tandzif harian kamar, fokus area bawah ranjang dan teras depan."
    },
    {
        "id": "manggil_orang",
        "name": "Manggil Orang",
        "category": "Komunikasi",
        "badge": "Gedor Pintu",
        "icon": "fa-bullhorn",
        "color": "from-blue-500 to-indigo-600",
        "desc": "Cari dan panggil a'do yang dicari: bangunkan kang molor, panggil ke pos piket, atau panggil untuk ro'an.",
        "default_notes": "Gedor Kamar 08, cari si Fulan bilang ditunggu di kantor mudabbir sekarang!"
    },
    {
        "id": "bawa_barang",
        "name": "Bawa Barang",
        "category": "Tenaga Ekstra",
        "badge": "Angkut Berat",
        "icon": "fa-boxes-packing",
        "color": "from-purple-500 to-indigo-700",
        "desc": "Bantuan angkut galon air isi ulang, koper santri baru, kardus kiriman wali, atau perabotan lemari.",
        "default_notes": "Bantu angkut 1 galon air dari pos satpam naik ke lantai 2."
    },
    {
        "id": "nitip_barang_bn",
        "name": "Nitip Barang BN",
        "category": "Keamanan & BN",
        "badge": "Baitun Maal / Paket",
        "icon": "fa-vault",
        "color": "from-indigo-600 to-violet-800",
        "desc": "Ambil dan amankan titipan paket di pos Baitun Maal / Pos Satpam agar aman dan tidak disita bagian keamanan.",
        "default_notes": "Ambilkan paket shopee atas nama ana di pos satpam sebelum jam tutup."
    },
    {
        "id": "anti_cepu",
        "name": "Anti Cepu",
        "category": "Spesial Santri",
        "badge": "Kerahasiaan 100%",
        "icon": "fa-user-secret",
        "color": "from-rose-600 to-red-800",
        "desc": "Mode operasi senyap: lindungi rahasia jastip, pantau pergerakan jasus/keamanan, enkripsi komunikasi santri.",
        "default_notes": "Pastikan jalur lorong steril dari pengurus keamanan, gunakan kode sandi bab Thaharah."
    },
    {
        "id": "minjem_baju",
        "name": "Minjem Baju",
        "category": "Fashion Syar'i",
        "badge": "Sarung & Koko",
        "icon": "fa-vest-patches",
        "color": "from-cyan-600 to-blue-700",
        "desc": "Pinjam sarung BHS/Wadimor licin, baju koko putih setrikaan rapi, peci hitam, atau jas untuk muhadhoroh.",
        "default_notes": "Pinjam sarung motif sutra halus + peci hitam ukuran 8 untuk acara malam ahad."
    },
    {
        "id": "samina_wa_atona",
        "name": "Sami'na Wa A'to'na",
        "category": "Komando Tertinggi",
        "badge": "Auto-Accept 100%",
        "icon": "fa-handshake-angle",
        "color": "from-amber-600 to-yellow-600",
        "desc": "Instruksi mutlak dari Rois Kamar / Lurah Pondok. Siapapun a'do yang terpilih WAJIB taat tanpa tapi!",
        "default_notes": "Perintah Rois: Segera kumpul di kamar sekarang juga untuk evaluasi piket."
    },
    {
        "id": "minta_mie",
        "name": "Minta Mie",
        "category": "Survival Malam",
        "badge": "Operasi Indomie",
        "icon": "fa-bowl-food",
        "color": "from-red-500 to-orange-600",
        "desc": "Nyeduh / masak Indomie goreng atau kuah malam hari, lengkap dengan telur setengah matang dan cabai rawit.",
        "default_notes": "Indomie Kari Ayam kuah kental + telor setengah matang + rawit 4 biji potong-potong."
    },
    {
        "id": "minta_seduhan",
        "name": "Minta Seduhan",
        "category": "Minuman Barokah",
        "badge": "Kopi & Susu",
        "icon": "fa-glass-water-droplet",
        "color": "from-emerald-600 to-teal-800",
        "desc": "Racikan seduhan pelepas kantuk santri: kopi hitam tubruk, Good Day freeze/mocca, teh poci melati, susu jahe hangat.",
        "default_notes": "Buatin kopi hitam kapal api manis sedang, jangan lupa diaduk sampai berbusa."
    }
]

def load_json(filepath, default):
    if not os.path.exists(filepath):
        save_json(filepath, default)
        return default
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return default

def save_json(filepath, data):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/services", methods=["GET"])
def get_services():
    return jsonify({"status": "success", "data": SERVICES})

@app.route("/api/members", methods=["GET"])
def get_members():
    members = load_json(MEMBERS_FILE, [])
    return jsonify({"status": "success", "data": members})

@app.route("/api/members/<member_id>", methods=["GET"])
def get_member(member_id):
    members = load_json(MEMBERS_FILE, [])
    member = next((m for m in members if m["id"] == member_id), None)
    if not member:
        return jsonify({"status": "error", "message": "A'do tidak ditemukan"}), 404
    return jsonify({"status": "success", "data": member})

@app.route("/api/gacha/roll", methods=["POST"])
def roll_gacha():
    """
    Sistem Gacha Santri GO A'DO:
    Weighting rarity:
    - UR (Ultra Rare - Lurah Pondok): 5%
    - SSR (Super Super Rare - Sepuh Gesit / Barista): 20%
    - SR (Super Rare - Chef / Tandzif / Vokal): 35%
    - R (Rare - Peminjam / Kang Pelor): 25%
    - N (Normal - A'do Baru): 15%
    """
    data = request.get_json() or {}
    roll_count = data.get("count", 1)
    service_id = data.get("service_id", None)
    
    members = load_json(MEMBERS_FILE, [])
    if not members:
        return jsonify({"status": "error", "message": "Pool A'do kosong"}), 400

    # Pool classification by rarity
    rarity_pools = {
        "UR": [m for m in members if m.get("rarity") == "UR"],
        "SSR": [m for m in members if m.get("rarity") == "SSR"],
        "SR": [m for m in members if m.get("rarity") == "SR"],
        "R": [m for m in members if m.get("rarity") == "R"],
        "N": [m for m in members if m.get("rarity") == "N"],
    }

    # Fallback if any pool is empty
    for r in ["UR", "SSR", "SR", "R", "N"]:
        if not rarity_pools[r]:
            rarity_pools[r] = members

    results = []
    
    # Rarity probabilities
    rarities = ["UR", "SSR", "SR", "R", "N"]
    weights = [0.06, 0.22, 0.35, 0.24, 0.13]

    for i in range(min(roll_count, 10)):
        chosen_rarity = random.choices(rarities, weights=weights, k=1)[0]
        chosen_pool = rarity_pools[chosen_rarity]
        selected_ado = random.choice(chosen_pool)

        # Dynamic santri reaction based on rarity and task
        reaction = ""
        if chosen_rarity == "UR":
            reaction = "⭐ KHIDMAH MUTLAK! Lurah Pondok turun tangan langsung! Tugas dijamin selesai 100%!"
        elif chosen_rarity == "SSR":
            reaction = "✨ HOKI BERKAH! A'do sepuh ahli taktik terpanggil! Eksekusi secepat kilat!"
        elif chosen_rarity == "SR":
            reaction = "⚡ MANTAP! A'do rajin dan cekatan siap meluncur!"
        elif chosen_rarity == "R":
            reaction = "😴 A'do kena gacha pas lagi santai! Harap digedor sekali biar bangun!"
        else:
            reaction = "🌱 A'do baru kena kocokan! Siap sami'na wa a'to'na tanpa membantah!"

        results.append({
            "ado": selected_ado,
            "rarity": selected_ado.get("rarity", chosen_rarity),
            "reaction": reaction,
            "roll_index": i + 1,
            "timestamp": datetime.now().strftime("%H:%M:%S")
        })

    return jsonify({
        "status": "success",
        "roll_count": len(results),
        "results": results,
        "selected_primary": results[0] if results else None
    })

@app.route("/api/orders", methods=["GET"])
def get_orders():
    orders = load_json(ORDERS_FILE, [])
    # Return reverse chronological
    return jsonify({"status": "success", "data": list(reversed(orders))})

@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.get_json() or {}
    service_id = data.get("service_id")
    requester = data.get("requester", "Santri Kamar")
    notes = data.get("notes", "")
    target_location = data.get("target_location", "Kamar Asrama")
    is_samina = data.get("is_samina", False)
    is_anti_cepu = data.get("is_anti_cepu", False)
    assigned_ado_id = data.get("assigned_ado_id", None)

    service = next((s for s in SERVICES if s["id"] == service_id), None)
    if not service:
        return jsonify({"status": "error", "message": "Layanan tidak valid"}), 400

    members = load_json(MEMBERS_FILE, [])
    
    # If not assigned or assigned randomly, pick via gacha
    assigned_ado = None
    if assigned_ado_id:
        assigned_ado = next((m for m in members if m["id"] == assigned_ado_id), None)
    
    if not assigned_ado and members:
        # Auto-gacha
        assigned_ado = random.choice(members)

    order_id = f"ORD-{random.randint(1000, 9999)}"
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    # If service is sami'na wa a'to'na, status starts directly as 'Diproses (Sami\'na)'
    initial_status = "Sedang Dikerjakan"
    if service_id == "samina_wa_atona" or is_samina:
        is_samina = True
        initial_status = "Diproses (Sami'na)"

    new_order = {
        "id": order_id,
        "service_id": service["id"],
        "service_name": service["name"],
        "service_icon": service["icon"],
        "requester": requester,
        "target_location": target_location,
        "notes": notes or service["default_notes"],
        "assigned_to": {
            "id": assigned_ado["id"] if assigned_ado else "unknown",
            "name": assigned_ado["name"] if assigned_ado else "Belum ditentukan",
            "nickname": assigned_ado.get("nickname", "A'do") if assigned_ado else "A'do",
            "rarity": assigned_ado.get("rarity", "N") if assigned_ado else "N",
            "title": assigned_ado.get("title", "") if assigned_ado else ""
        },
        "status": initial_status,
        "is_samina": is_samina,
        "is_anti_cepu": is_anti_cepu,
        "has_review": False,
        "created_at": now_str,
        "completed_at": None
    }

    orders = load_json(ORDERS_FILE, [])
    orders.append(new_order)
    save_json(ORDERS_FILE, orders)

    return jsonify({"status": "success", "message": "Order GO A'DO berhasil dibuat!", "data": new_order})

@app.route("/api/orders/<order_id>/status", methods=["POST"])
def update_order_status(order_id):
    data = request.get_json() or {}
    new_status = data.get("status")
    valid_statuses = ["Menunggu", "Sedang Dikerjakan", "Diproses (Sami'na)", "Selesai", "Dibatalkan"]
    if new_status not in valid_statuses:
        return jsonify({"status": "error", "message": "Status tidak valid"}), 400

    orders = load_json(ORDERS_FILE, [])
    order = next((o for o in orders if o["id"] == order_id), None)
    if not order:
        return jsonify({"status": "error", "message": "Order tidak ditemukan"}), 404

    order["status"] = new_status
    if new_status == "Selesai":
        order["completed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")

    save_json(ORDERS_FILE, orders)
    return jsonify({"status": "success", "message": f"Status diperbarui menjadi: {new_status}", "data": order})

@app.route("/api/reviews", methods=["GET"])
def get_reviews():
    reviews = load_json(REVIEWS_FILE, [])
    return jsonify({"status": "success", "data": list(reversed(reviews))})

@app.route("/api/reviews", methods=["POST"])
def add_review():
    """
    Review berbasis bintang 1 sampai 5 bintang.
    """
    data = request.get_json() or {}
    order_id = data.get("order_id")
    member_id = data.get("member_id")
    service_id = data.get("service_id")
    rating = int(data.get("rating", 5))
    user_name = data.get("user_name", "Santri Hamba Allah")
    comment = data.get("comment", "Barokallah, khidmah sangat memuaskan!")
    tags = data.get("tags", ["Barokah", "Amanah"])

    # Validasi rating bintang 1 - 5
    if rating < 1 or rating > 5:
        return jsonify({"status": "error", "message": "Rating harus antara 1 sampai 5 bintang!"}), 400

    members = load_json(MEMBERS_FILE, [])
    member = next((m for m in members if m["id"] == member_id), None)
    member_name = member["name"] if member else "A'do Santri"

    service = next((s for s in SERVICES if s["id"] == service_id), None)
    service_name = service["name"] if service else "Layanan Santri"

    review_id = f"rev-{random.randint(100, 9999)}"
    new_review = {
        "id": review_id,
        "order_id": order_id,
        "member_id": member_id,
        "member_name": member_name,
        "service_id": service_id,
        "service_name": service_name,
        "rating": rating,
        "user_name": user_name,
        "comment": comment,
        "tags": tags,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }

    reviews = load_json(REVIEWS_FILE, [])
    reviews.append(new_review)
    save_json(REVIEWS_FILE, reviews)

    # Recalculate member's rating
    if member:
        member_reviews = [r for r in reviews if r.get("member_id") == member_id]
        if member_reviews:
            total_score = sum(r["rating"] for r in member_reviews)
            member["rating"] = round(total_score / len(member_reviews), 2)
            member["review_count"] = len(member_reviews)
            save_json(MEMBERS_FILE, members)

    # Mark order as reviewed if order_id is provided
    if order_id:
        orders = load_json(ORDERS_FILE, [])
        order = next((o for o in orders if o["id"] == order_id), None)
        if order:
            order["has_review"] = True
            save_json(ORDERS_FILE, orders)

    return jsonify({"status": "success", "message": "Ulasan bintang berhasil dikirim!", "data": new_review})

@app.route("/api/stats", methods=["GET"])
def get_stats():
    orders = load_json(ORDERS_FILE, [])
    reviews = load_json(REVIEWS_FILE, [])
    members = load_json(MEMBERS_FILE, [])

    total_orders = len(orders)
    completed_orders = len([o for o in orders if o.get("status") == "Selesai"])
    avg_rating = round(sum(r["rating"] for r in reviews) / len(reviews), 2) if reviews else 5.0

    # Top A'do leaderboard
    top_members = sorted(members, key=lambda x: (x.get("rating", 0), x.get("review_count", 0)), reverse=True)[:5]

    return jsonify({
        "status": "success",
        "data": {
            "total_orders": total_orders,
            "completed_orders": completed_orders,
            "total_reviews": len(reviews),
            "avg_rating": avg_rating,
            "five_star_reviews": len([r for r in reviews if r.get("rating") == 5]),
            "leaderboard": top_members
        }
    })

if __name__ == "__main__":
    print("=" * 60)
    print("🟢 GO A'DO - Aplikasi Santri & Khidmah Serbaguna")
    print("🌐 Mengakses server di: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host="127.0.0.1", port=5000, debug=True)
