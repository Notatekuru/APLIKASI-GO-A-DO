import sys
import webbrowser
import threading
import time
from app import app

def open_browser():
    time.sleep(1.2)
    url = "http://127.0.0.1:5000"
    print(f"\n🚀 Membuka GO A'DO di browser: {url}\n")
    webbrowser.open(url)

if __name__ == "__main__":
    print("=" * 65)
    print("🕌 GO A'DO - SuperApp Khidmah, Jastip & Asrama Santri On-Demand")
    print("=" * 65)
    print("✨ Fitur Lengkap:")
    print("  1. 🎲 Sistem Gacha Memilih Orang (UR / SSR / SR / R / N)")
    print("  2. ⭐ Fitur Ulasan & Review Berbasis Bintang (1 - 5 Bintang)")
    print("  3. ♨️ 14 Layanan Khusus Santri:")
    print("     - Air Panas          - Angkat Cucian      - Ambil Nasi")
    print("     - Beli Idam          - Nitip Makanan      - Tandzif")
    print("     - Manggil Orang      - Bawa Barang        - Nitip Barang BN")
    print("     - Anti Cepu          - Minjem Baju        - Sami'na Wa A'to'na")
    print("     - Minta Mie          - Minta Seduhan")
    print("  4. 🚨 Panic Button 'Anti Cepu' (Tombol ESC: Seketika Tampil Kitab Kuning)")
    print("=" * 65)

    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, debug=False)
