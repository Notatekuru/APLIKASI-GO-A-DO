@echo off
title GO A'DO - SuperApp Khidmah Santri
echo ========================================================
echo  Menjalankan GO A'DO (Santri Edition)...
echo ========================================================
python run.py
pause
