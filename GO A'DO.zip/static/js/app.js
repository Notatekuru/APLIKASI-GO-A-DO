// GO A'DO Frontend Application Logic
// Features: 14 Services, Gacha System, 5-Star Reviews, Anti-Cepu Panic Button, Web Audio SFX

let allServices = [];
let allMembers = [];
let allOrders = [];
let allReviews = [];
let audioCtx = null;

// Audio Synthesizer using Web Audio API (No external sound files required)
function getAudioContext() {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) {
      audioCtx = new AudioContext();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function playTone(freq, type = 'sine', duration = 0.2, gainLevel = 0.1) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(gainLevel, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (e) {
    // Audio might be blocked by browser autoplay policy until user interacts
  }
}

function playChime() {
  playTone(523.25, 'triangle', 0.25, 0.15); // C5
  setTimeout(() => playTone(659.25, 'triangle', 0.3, 0.15), 100); // E5
  setTimeout(() => playTone(783.99, 'triangle', 0.4, 0.15), 200); // G5
  setTimeout(() => playTone(1046.50, 'triangle', 0.5, 0.2), 300); // C6
}

function playStarSound(stars) {
  const baseFreq = 400 + (stars * 120);
  playTone(baseFreq, 'sine', 0.15, 0.15);
}

function playGachaDrumroll() {
  for (let i = 0; i < 8; i++) {
    setTimeout(() => {
      playTone(180 + (i * 25), 'sawtooth', 0.08, 0.08);
    }, i * 70);
  }
}

function playGachaFanfare(rarity) {
  if (rarity === 'UR' || rarity === 'SSR') {
    // Epic fanfare
    playTone(523.25, 'sine', 0.2, 0.2); // C5
    setTimeout(() => playTone(659.25, 'sine', 0.2, 0.2), 150); // E5
    setTimeout(() => playTone(783.99, 'sine', 0.2, 0.2), 300); // G5
    setTimeout(() => playTone(1046.50, 'triangle', 0.7, 0.3), 450); // C6
    setTimeout(() => playTone(1318.51, 'triangle', 0.8, 0.25), 650); // E6
  } else {
    // Normal fanfare
    playTone(440, 'triangle', 0.2, 0.15);
    setTimeout(() => playTone(554.37, 'triangle', 0.2, 0.15), 150);
    setTimeout(() => playTone(659.25, 'triangle', 0.4, 0.2), 300);
  }
}

// Initialization on load
document.addEventListener('DOMContentLoaded', () => {
  initApp();

  // Keyboard shortcut ESC to trigger Anti Cepu Panic Button
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.key === 'F2') {
      const disguise = document.getElementById('antiCepuDisguise');
      const isHidden = disguise.classList.contains('hidden');
      toggleAntiCepuDisguise(isHidden);
    }
  });
});

async function initApp() {
  await Promise.all([
    loadServices(),
    loadMembers(),
    loadOrders(),
    loadReviews(),
    loadStats()
  ]);
}

// ==================== TABS MANAGEMENT ====================
function switchTab(tabId) {
  document.querySelectorAll('.tab-view').forEach(el => el.classList.add('hidden'));
  const targetView = document.getElementById(`view-${tabId}`);
  if (targetView) targetView.classList.remove('hidden');

  // Update desktop nav buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('bg-emerald-600', 'text-white', 'shadow-md');
    btn.classList.add('text-slate-300');
  });
  const activeBtn = document.getElementById(`tab-btn-${tabId}`);
  if (activeBtn) {
    activeBtn.classList.add('bg-emerald-600', 'text-white', 'shadow-md');
    activeBtn.classList.remove('text-slate-300');
  }

  // Update mobile buttons
  document.querySelectorAll('.mobile-tab-btn').forEach(btn => {
    btn.classList.remove('bg-emerald-600', 'text-white');
    btn.classList.add('text-slate-300', 'bg-slate-800');
  });
  const mobBtn = document.getElementById(`mob-tab-${tabId}`);
  if (mobBtn) {
    mobBtn.classList.add('bg-emerald-600', 'text-white');
    mobBtn.classList.remove('text-slate-300', 'bg-slate-800');
  }
}

// ==================== LOAD & RENDER SERVICES ====================
async function loadServices() {
  try {
    const res = await fetch('/api/services');
    const json = await res.json();
    if (json.status === 'success') {
      allServices = json.data;
      renderServices(allServices);
    }
  } catch (err) {
    console.error('Failed to load services:', err);
  }
}

function renderServices(services) {
  const container = document.getElementById('servicesGrid');
  if (!container) return;

  container.innerHTML = services.map(svc => `
    <div class="service-card bg-slate-800/80 hover:bg-slate-800 border border-slate-700/70 hover:border-emerald-500/50 rounded-2xl p-5 shadow-lg flex flex-col justify-between group cursor-pointer" onclick="openOrderModalForService('${svc.id}')">
      <div>
        <div class="flex items-center justify-between mb-3">
          <div class="w-12 h-12 rounded-2xl bg-gradient-to-br ${svc.color} flex items-center justify-center text-white text-xl shadow-md group-hover:scale-110 transition-transform">
            <i class="fa-solid ${svc.icon}"></i>
          </div>
          <span class="text-[10px] font-bold px-2.5 py-1 rounded-full bg-slate-700/80 text-emerald-300 border border-slate-600">
            ${svc.badge}
          </span>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-emerald-400 transition-colors flex items-center justify-between">
          <span>${svc.name}</span>
          <i class="fa-solid fa-chevron-right text-xs text-slate-500 group-hover:translate-x-1 transition-transform"></i>
        </h3>
        <p class="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
          ${svc.desc}
        </p>
      </div>

      <div class="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-xs">
        <span class="text-slate-500">${svc.category}</span>
        <span class="text-emerald-400 font-bold flex items-center">
          <i class="fa-solid fa-dice mr-1 text-amber-400"></i> Gacha A'do
        </span>
      </div>
    </div>
  `).join('');
}

function filterServicesByCategory() {
  const cat = document.getElementById('serviceCategoryFilter').value;
  if (cat === 'ALL') {
    renderServices(allServices);
  } else {
    const filtered = allServices.filter(s => s.category.toLowerCase().includes(cat.toLowerCase()));
    renderServices(filtered);
  }
}

// ==================== LOAD & RENDER MEMBERS ====================
async function loadMembers() {
  try {
    const res = await fetch('/api/members');
    const json = await res.json();
    if (json.status === 'success') {
      allMembers = json.data;
      renderMembers(allMembers);
      populateMemberSelectDropdown(allMembers);
    }
  } catch (err) {
    console.error('Failed to load members:', err);
  }
}

function renderMembers(members) {
  const container = document.getElementById('membersContainer');
  if (!container) return;

  container.innerHTML = members.map(m => `
    <div class="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
      <!-- Rarity Watermark -->
      <div class="absolute -top-3 -right-2 text-5xl font-black opacity-10 pointer-events-none text-slate-400">
        ${m.rarity}
      </div>

      <div>
        <div class="flex items-start space-x-3.5 mb-3">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-br ${m.avatar_bg} flex items-center justify-center text-white text-2xl shadow-md border border-white/20 flex-shrink-0">
            <i class="fa-solid fa-${m.avatar_icon}"></i>
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center space-x-2">
              <span class="px-2 py-0.5 rounded text-[10px] font-black tracking-wider uppercase border rarity-${m.rarity}">
                ${m.rarity}
              </span>
              <span class="text-xs font-semibold text-emerald-400">${m.nickname}</span>
            </div>
            <h4 class="text-sm font-bold text-white truncate mt-0.5">${m.name}</h4>
            <div class="text-[11px] text-slate-400 truncate">${m.kamar}</div>
          </div>
        </div>

        <div class="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 text-xs mb-3">
          <div class="text-[10px] text-slate-400 font-semibold uppercase">Spesialisasi:</div>
          <div class="text-amber-300 font-medium mt-0.5">${m.specialty}</div>
        </div>

        <p class="text-xs italic text-slate-300 bg-slate-900/30 p-2 rounded-lg border-l-2 border-emerald-500 mb-3">
          "${m.quote}"
        </p>

        <!-- Traits -->
        <div class="flex flex-wrap gap-1 mb-3">
          ${(m.traits || []).map(t => `
            <span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-700 text-slate-300">${t}</span>
          `).join('')}
        </div>
      </div>

      <div class="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
        <div class="flex items-center text-amber-400 font-bold">
          <i class="fa-solid fa-star mr-1"></i>
          <span>${m.rating}</span>
          <span class="text-slate-500 ml-1 font-normal">(${m.review_count} ulasan)</span>
        </div>
        <button onclick="orderDirectlyWithAdo('${m.id}')" class="px-3 py-1.5 rounded-xl bg-emerald-600/80 hover:bg-emerald-500 text-white font-bold text-xs transition">
          Pilih A'do Ini
        </button>
      </div>
    </div>
  `).join('');
}

function populateMemberSelectDropdown(members) {
  const select = document.getElementById('orderManualAdoId');
  if (!select) return;
  select.innerHTML = members.map(m => `
    <option value="${m.id}">[${m.rarity}] ${m.name} (${m.nickname}) - ⭐ ${m.rating}</option>
  `).join('');
}

// ==================== LOAD & RENDER ORDERS ====================
async function loadOrders() {
  try {
    const res = await fetch('/api/orders');
    const json = await res.json();
    if (json.status === 'success') {
      allOrders = json.data;
      renderOrders(allOrders);

      // Update badge
      const activeCount = allOrders.filter(o => o.status !== 'Selesai' && o.status !== 'Dibatalkan').length;
      const badge = document.getElementById('orderBadgeCount');
      if (badge) badge.innerText = activeCount;
    }
  } catch (err) {
    console.error('Failed to load orders:', err);
  }
}

function renderOrders(orders) {
  const container = document.getElementById('ordersContainer');
  if (!container) return;

  if (orders.length === 0) {
    container.innerHTML = `
      <div class="text-center py-16 bg-slate-800/40 rounded-3xl border border-dashed border-slate-700">
        <div class="w-16 h-16 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-500 text-2xl mb-3">
          <i class="fa-solid fa-clipboard-list"></i>
        </div>
        <h4 class="text-base font-bold text-white">Belum Ada Pesanan Khidmah</h4>
        <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">Klik salah satu dari 14 layanan untuk membuat pesanan dan mengocok petugas A'do!</p>
        <button onclick="openCustomOrderModal()" class="mt-4 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs">
          Buat Pesanan Sekarang
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = orders.map(ord => {
    let statusBadge = '';
    if (ord.status === 'Selesai') {
      statusBadge = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"><i class="fa-solid fa-check mr-1"></i>Selesai</span>';
    } else if (ord.status === "Diproses (Sami'na)") {
      statusBadge = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse"><i class="fa-solid fa-handshake-angle mr-1"></i>Sami\'na Wa A\'to\'na</span>';
    } else {
      statusBadge = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30"><i class="fa-solid fa-spinner fa-spin mr-1"></i>Sedang Dikerjakan</span>';
    }

    const isFinished = ord.status === 'Selesai';
    const hasReview = ord.has_review;

    return `
      <div class="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <!-- Left: Service & Info -->
        <div class="flex items-start space-x-4">
          <div class="w-12 h-12 rounded-2xl bg-emerald-700/40 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-xl flex-shrink-0">
            <i class="fa-solid ${ord.service_icon || 'fa-bell'}"></i>
          </div>
          <div>
            <div class="flex items-center space-x-2">
              <span class="text-xs font-mono text-slate-400">${ord.id}</span>
              ${ord.is_anti_cepu ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800"><i class="fa-solid fa-user-secret mr-1"></i>Anti Cepu</span>' : ''}
              ${ord.is_samina ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">Sami\'na</span>' : ''}
            </div>
            <h4 class="text-base font-bold text-white mt-0.5">${ord.service_name}</h4>
            <div class="text-xs text-slate-400 mt-1">
              Pemesan: <strong class="text-slate-200">${ord.requester}</strong> • Lokasi: <span class="text-slate-300">${ord.target_location || 'Kamar'}</span>
            </div>
            <p class="text-xs text-slate-300 bg-slate-900/60 p-2 rounded-lg mt-2 border border-slate-800/60 max-w-xl">
              "${ord.notes}"
            </p>
          </div>
        </div>

        <!-- Middle: Assigned A'do -->
        <div class="bg-slate-900/70 p-3 rounded-xl border border-slate-700/60 min-w-[200px]">
          <div class="text-[10px] text-slate-400 font-semibold uppercase">Petugas A'do (Hasil Gacha):</div>
          <div class="flex items-center space-x-2 mt-1">
            <span class="px-1.5 py-0.5 rounded text-[10px] font-black border rarity-${ord.assigned_to.rarity || 'N'}">
              ${ord.assigned_to.rarity || 'A\'DO'}
            </span>
            <span class="text-xs font-bold text-white truncate">${ord.assigned_to.name}</span>
          </div>
          <div class="text-[11px] text-emerald-400 font-medium truncate mt-0.5">
            ${ord.assigned_to.title || ord.assigned_to.nickname}
          </div>
        </div>

        <!-- Right: Status & Actions -->
        <div class="flex flex-col sm:items-end justify-between space-y-3 min-w-[170px]">
          <div>${statusBadge}</div>
          <div class="text-[10px] text-slate-500">${ord.created_at}</div>

          <div class="flex flex-wrap gap-2">
            ${!isFinished ? `
              <button onclick="updateOrderStatus('${ord.id}', 'Selesai')" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition flex items-center space-x-1">
                <i class="fa-solid fa-check"></i>
                <span>Tandai Selesai</span>
              </button>
            ` : ''}

            ${isFinished && !hasReview ? `
              <button onclick="openReviewModalForOrder('${ord.id}', '${ord.assigned_to.id}', '${ord.service_id}', '${ord.assigned_to.name}')" class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-xs shadow-md transition flex items-center space-x-1">
                <i class="fa-solid fa-star"></i>
                <span>Beri Bintang 5</span>
              </button>
            ` : ''}

            ${hasReview ? `
              <span class="text-xs text-amber-400 font-bold flex items-center">
                <i class="fa-solid fa-star mr-1"></i> Sudah Direview
              </span>
            ` : ''}
          </div>
        </div>

      </div>
    `;
  }).join('');
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    const json = await res.json();
    if (json.status === 'success') {
      playChime();
      showToast(json.message, 'success');
      await loadOrders();
      await loadStats();
    }
  } catch (err) {
    showToast('Gagal mengubah status', 'error');
  }
}

// ==================== ORDER MODAL LOGIC ====================
function openOrderModalForService(serviceId) {
  const svc = allServices.find(s => s.id === serviceId);
  if (!svc) return;

  document.getElementById('orderServiceId').value = svc.id;
  document.getElementById('modalServiceName').innerText = svc.name;
  document.getElementById('modalServiceCategory').innerText = svc.category;
  document.getElementById('modalServiceDesc').innerText = svc.desc;
  document.getElementById('modalServiceIcon').className = `fa-solid ${svc.icon}`;
  document.getElementById('orderNotes').value = svc.default_notes;

  // Preset checkboxes based on service type
  document.getElementById('orderIsAntiCepu').checked = (svc.id === 'anti_cepu');
  document.getElementById('orderIsSamina').checked = (svc.id === 'samina_wa_atona');

  // Reset type to gacha
  document.querySelector('input[name="adoSelectionType"][value="gacha"]').checked = true;
  toggleAdoSelectionMethod();

  document.getElementById('orderModal').classList.remove('hidden');
}

function openCustomOrderModal() {
  if (allServices.length > 0) {
    openOrderModalForService(allServices[0].id);
  }
}

function closeOrderModal() {
  document.getElementById('orderModal').classList.add('hidden');
}

function toggleAdoSelectionMethod() {
  const method = document.querySelector('input[name="adoSelectionType"]:checked').value;
  const manualBox = document.getElementById('manualAdoSelectBox');
  if (method === 'manual') {
    manualBox.classList.remove('hidden');
  } else {
    manualBox.classList.add('hidden');
  }
}

function orderDirectlyWithAdo(memberId) {
  openCustomOrderModal();
  document.querySelector('input[name="adoSelectionType"][value="manual"]').checked = true;
  toggleAdoSelectionMethod();
  const select = document.getElementById('orderManualAdoId');
  if (select) select.value = memberId;
}

async function submitOrder(e) {
  e.preventDefault();
  const serviceId = document.getElementById('orderServiceId').value;
  const requester = document.getElementById('orderRequester').value;
  const targetLocation = document.getElementById('orderTargetLocation').value;
  const notes = document.getElementById('orderNotes').value;
  const isAntiCepu = document.getElementById('orderIsAntiCepu').checked;
  const isSamina = document.getElementById('orderIsSamina').checked;

  const method = document.querySelector('input[name="adoSelectionType"]:checked').value;
  let assignedAdoId = null;
  if (method === 'manual') {
    assignedAdoId = document.getElementById('orderManualAdoId').value;
  }

  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: serviceId,
        requester: requester,
        target_location: targetLocation,
        notes: notes,
        is_anti_cepu: isAntiCepu,
        is_samina: isSamina,
        assigned_ado_id: assignedAdoId
      })
    });
    const json = await res.json();
    if (json.status === 'success') {
      closeOrderModal();
      playChime();
      showToast('Khidmah berhasil diorder! A\'do terpilih siap jalan!', 'success');

      // If it was gacha, also celebrate with cutscene
      if (method === 'gacha' && json.data.assigned_to) {
        const assigned = allMembers.find(m => m.id === json.data.assigned_to.id);
        if (assigned) {
          triggerGachaCutsceneSingle({
            ado: assigned,
            rarity: assigned.rarity,
            reaction: isSamina ? "✋ SAMI'NA WA A'TO'NA! Perintah rois wajib dilaksanakan 100%!" : "🎲 Terpanggil melalui gacha khidmah!",
            timestamp: new Date().toLocaleTimeString()
          });
        }
      }

      await loadOrders();
      await loadStats();
      switchTab('orders');
    }
  } catch (err) {
    showToast('Gagal memproses pesanan', 'error');
  }
}

// ==================== GACHA SYSTEM ====================
async function executeGacha(count = 1) {
  playGachaDrumroll();

  // Animate Portal Box
  const portal = document.getElementById('gachaPortalBox');
  const icon = document.getElementById('portalIcon');
  const text = document.getElementById('portalStatusText');
  if (portal) portal.classList.add('gacha-active');
  if (icon) icon.className = 'text-6xl text-amber-300 fa-solid fa-spinner fa-spin';
  if (text) text.innerText = 'MENGOCOK SANTRI...';

  try {
    const res = await fetch('/api/gacha/roll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count: count })
    });
    const json = await res.json();

    setTimeout(() => {
      if (portal) portal.classList.remove('gacha-active');
      if (icon) icon.className = 'text-6xl text-amber-400 fa-solid fa-dice-d20';
      if (text) text.innerText = 'SIAP DIKOCOK';

      if (json.status === 'success') {
        const results = json.results;

        // Sound fanfare according to top rarity
        const topRarity = results.some(r => r.rarity === 'UR') ? 'UR' : (results.some(r => r.rarity === 'SSR') ? 'SSR' : 'SR');
        playGachaFanfare(topRarity);

        // Show Cutscene for single pull
        if (results.length === 1) {
          triggerGachaCutsceneSingle(results[0]);
        } else {
          // Show quick popup for multi pull
          showToast(`Kocokan 5x Santri Sukses! Top: ${topRarity}`, 'success');
        }

        // Render to Gacha History
        renderGachaHistory(results);
      }
    }, 700);

  } catch (err) {
    if (portal) portal.classList.remove('gacha-active');
    showToast('Gagal mengocok gacha', 'error');
  }
}

function triggerQuickGacha() {
  switchTab('gacha');
  executeGacha(1);
}

function triggerGachaCutsceneSingle(result) {
  const modal = document.getElementById('gachaCutsceneModal');
  const animContainer = document.getElementById('gachaAnimationContainer');
  const cardReveal = document.getElementById('gachaCardReveal');
  const card = document.getElementById('gachaResultCard');

  // Fill in Data
  const m = result.ado;
  document.getElementById('gachaResultRarity').innerText = result.rarity;
  document.getElementById('gachaResultRarity').className = `px-3 py-1 rounded-full text-xs font-black tracking-widest border uppercase rarity-${result.rarity}`;
  document.getElementById('gachaResultTimestamp').innerText = result.timestamp || new Date().toLocaleTimeString();
  document.getElementById('gachaResultName').innerText = m.name;
  document.getElementById('gachaResultNickname').innerText = `"${m.nickname}"`;
  document.getElementById('gachaResultKamar').innerText = m.kamar;
  document.getElementById('gachaResultRating').innerText = m.rating;
  document.getElementById('gachaResultTitle').innerText = m.title;
  document.getElementById('gachaResultQuote').innerText = `"${m.quote}"`;
  document.getElementById('gachaResultReaction').innerText = result.reaction;

  const iconEl = document.getElementById('gachaResultIcon');
  iconEl.className = `fa-solid fa-${m.avatar_icon}`;

  const avatarBox = document.getElementById('gachaResultAvatarBox');
  avatarBox.className = `w-24 h-24 mx-auto rounded-3xl flex items-center justify-center text-4xl text-white shadow-xl mb-4 bg-gradient-to-br ${m.avatar_bg}`;

  // Card border styling
  card.className = `card-gacha bg-gradient-to-b from-slate-800 to-slate-900 border-2 rounded-3xl p-6 shadow-2xl relative overflow-hidden transform transition-all duration-500 scale-95 opacity-0 rarity-${result.rarity}`;

  // Reset cutscene states
  modal.classList.remove('hidden');
  animContainer.classList.remove('hidden');
  cardReveal.classList.add('hidden');

  // Step 2: Reveal card after short delay
  setTimeout(() => {
    animContainer.classList.add('hidden');
    cardReveal.classList.remove('hidden');

    setTimeout(() => {
      card.classList.remove('scale-95', 'opacity-0');
      card.classList.add('scale-100', 'opacity-100');
    }, 50);
  }, 1000);
}

function closeGachaCutscene() {
  document.getElementById('gachaCutsceneModal').classList.add('hidden');
}

function renderGachaHistory(results) {
  const container = document.getElementById('gachaHistoryList');
  if (!container) return;

  // Clear placeholder if present
  if (container.querySelector('.col-span-full')) {
    container.innerHTML = '';
  }

  const html = results.map(r => `
    <div class="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-3.5 shadow-md flex flex-col justify-between transform hover:-translate-y-1 transition duration-200">
      <div>
        <div class="flex items-center justify-between mb-2">
          <span class="text-[10px] font-black px-2 py-0.5 rounded border rarity-${r.rarity}">${r.rarity}</span>
          <span class="text-[10px] text-slate-500">${r.timestamp}</span>
        </div>
        <div class="flex items-center space-x-2">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br ${r.ado.avatar_bg} flex items-center justify-center text-white text-xs">
            <i class="fa-solid fa-${r.ado.avatar_icon}"></i>
          </div>
          <div class="min-w-0 flex-1">
            <div class="text-xs font-bold text-white truncate">${r.ado.nickname}</div>
            <div class="text-[10px] text-slate-400 truncate">${r.ado.kamar}</div>
          </div>
        </div>
        <p class="text-[10px] text-slate-300 italic mt-2 bg-slate-900/40 p-1.5 rounded line-clamp-2">
          "${r.ado.quote}"
        </p>
      </div>
      <div class="mt-3 pt-2 border-t border-slate-700 flex justify-between items-center text-[10px]">
        <span class="text-amber-400 font-bold"><i class="fa-solid fa-star"></i> ${r.ado.rating}</span>
        <button onclick="orderDirectlyWithAdo('${r.ado.id}')" class="text-emerald-400 font-bold hover:underline">
          Tugaskan
        </button>
      </div>
    </div>
  `).join('');

  container.insertAdjacentHTML('afterbegin', html);
}

// ==================== 5-STAR REVIEWS SYSTEM ====================
async function loadReviews() {
  try {
    const res = await fetch('/api/reviews');
    const json = await res.json();
    if (json.status === 'success') {
      allReviews = json.data;
      renderReviews(allReviews);
    }
  } catch (err) {
    console.error('Failed to load reviews:', err);
  }
}

function renderReviews(reviews) {
  const container = document.getElementById('reviewsContainer');
  if (!container) return;

  if (reviews.length === 0) {
    container.innerHTML = `
      <div class="col-span-full text-center py-12 text-slate-500 text-sm italic">
        Belum ada ulasan bintang. Selesaikan tugas untuk memberi rating pertama!
      </div>
    `;
    return;
  }

  container.innerHTML = reviews.map(rev => {
    // Generate star icons
    let starsHtml = '';
    for (let i = 1; i <= 5; i++) {
      if (i <= rev.rating) {
        starsHtml += '<i class="fa-solid fa-star text-amber-400"></i>';
      } else {
        starsHtml += '<i class="fa-regular fa-star text-slate-600"></i>';
      }
    }

    return `
      <div class="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
        <div>
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center space-x-1 text-sm">
              ${starsHtml}
              <span class="text-xs font-bold text-amber-300 ml-1.5">${rev.rating}.0</span>
            </div>
            <span class="text-[10px] text-slate-500 font-mono">${rev.created_at}</span>
          </div>

          <div class="flex items-center space-x-2 text-xs mb-2">
            <span class="font-bold text-white">${rev.user_name}</span>
            <span class="text-slate-500">•</span>
            <span class="text-emerald-400 font-medium">${rev.service_name}</span>
          </div>

          <p class="text-xs text-slate-300 leading-relaxed bg-slate-900/50 p-3 rounded-xl border border-slate-800">
            "${rev.comment}"
          </p>

          <div class="flex flex-wrap gap-1.5 mt-3">
            ${(rev.tags || []).map(t => `
              <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800/50">#${t}</span>
            `).join('')}
          </div>
        </div>

        <div class="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
          <span>Petugas A'do:</span>
          <span class="font-bold text-slate-200">${rev.member_name}</span>
        </div>
      </div>
    `;
  }).join('');
}

function filterReviews(starValue) {
  document.querySelectorAll('.review-filter-btn').forEach(b => b.classList.remove('bg-emerald-600', 'text-white'));
  event.target.classList.add('bg-emerald-600', 'text-white');

  if (starValue === 0) {
    renderReviews(allReviews);
  } else if (starValue === 3) {
    renderReviews(allReviews.filter(r => r.rating <= 3));
  } else {
    renderReviews(allReviews.filter(r => r.rating === starValue));
  }
}

// Review Modal Handling
function openReviewModalForOrder(orderId, memberId, serviceId, memberName) {
  document.getElementById('reviewOrderId').value = orderId;
  document.getElementById('reviewMemberId').value = memberId;
  document.getElementById('reviewServiceId').value = serviceId;
  document.getElementById('reviewSubtitle').innerText = `Ulasan untuk khidmah ${memberName}`;
  setStarRating(5);
  document.getElementById('reviewModal').classList.remove('hidden');
}

function openNewReviewModalDirect() {
  if (allMembers.length > 0 && allServices.length > 0) {
    openReviewModalForOrder('', allMembers[0].id, allServices[0].id, allMembers[0].name);
  }
}

function closeReviewModal() {
  document.getElementById('reviewModal').classList.add('hidden');
}

function setStarRating(val) {
  document.getElementById('selectedStarValue').value = val;
  playStarSound(val);
  updateStarButtonsVisual(val);

  const feedbackMap = {
    1: '⭐ (Kurang Barokah - Perlu Introspeksi)',
    2: '⭐⭐ (Butuh Istighfar & Perbaikan)',
    3: '⭐⭐⭐ (Alhamdulillah - Lumayan Baik)',
    4: '⭐⭐⭐⭐ (Mantap Jiwa - Sangat Membantu)',
    5: '⭐⭐⭐⭐⭐ (Masya Allah Tabarakallah - Istimewa & Barokah!)'
  };
  document.getElementById('starFeedbackText').innerText = feedbackMap[val] || '';
}

function previewStars(val) {
  updateStarButtonsVisual(val);
}

function resetStarPreview() {
  const currentVal = parseInt(document.getElementById('selectedStarValue').value) || 5;
  updateStarButtonsVisual(currentVal);
}

function updateStarButtonsVisual(val) {
  const buttons = document.querySelectorAll('#starRatingContainer .star-btn');
  buttons.forEach((btn, idx) => {
    const starIdx = idx + 1;
    if (starIdx <= val) {
      btn.className = 'star-btn text-amber-400 transition transform hover:scale-125 focus:outline-none';
      btn.innerHTML = '<i class="fa-solid fa-star"></i>';
    } else {
      btn.className = 'star-btn text-slate-600 transition transform hover:scale-125 focus:outline-none';
      btn.innerHTML = '<i class="fa-regular fa-star"></i>';
    }
  });
}

function toggleTag(btn, tagName) {
  btn.classList.toggle('active');
}

async function submitReview(e) {
  e.preventDefault();
  const orderId = document.getElementById('reviewOrderId').value;
  const memberId = document.getElementById('reviewMemberId').value;
  const serviceId = document.getElementById('reviewServiceId').value;
  const rating = parseInt(document.getElementById('selectedStarValue').value) || 5;
  const userName = document.getElementById('reviewUserName').value;
  const comment = document.getElementById('reviewComment').value;

  const activeTagButtons = document.querySelectorAll('#reviewTagsContainer .tag-chip.active');
  const tags = Array.from(activeTagButtons).map(b => b.innerText.replace('#', ''));

  try {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        order_id: orderId,
        member_id: memberId,
        service_id: serviceId,
        rating: rating,
        user_name: userName,
        comment: comment,
        tags: tags
      })
    });
    const json = await res.json();
    if (json.status === 'success') {
      closeReviewModal();
      playChime();
      showToast('Ulasan berkah bintang 5 berhasil dikirim!', 'success');
      await loadReviews();
      await loadOrders();
      await loadMembers();
      await loadStats();
      switchTab('reviews');
    }
  } catch (err) {
    showToast('Gagal mengirim ulasan', 'error');
  }
}

// ==================== ANTI CEPU DISGUISE (PANIC BUTTON) ====================
function toggleAntiCepuDisguise(show) {
  const disguise = document.getElementById('antiCepuDisguise');
  if (show) {
    disguise.classList.remove('hidden');
    document.title = 'المكتبة الشاملة - فتح القريب المجيب';
    playTone(300, 'sine', 0.1, 0.05); // subtle stealth audio cue
  } else {
    disguise.classList.add('hidden');
    document.title = "GO A'DO - SuperApp Khidmah & Santri On-Demand";
    playChime();
    showToast("Mode Rahasia Dimatikan: Selamat datang kembali di GO A'DO!", 'info');
  }
}

// ==================== STATS & COUNTERS ====================
async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    const json = await res.json();
    if (json.status === 'success') {
      const d = json.data;
      document.getElementById('statTotalOrders').innerText = d.total_orders;
      document.getElementById('statCompletedOrders').innerText = d.completed_orders;
      document.getElementById('statAvgRating').innerText = d.avg_rating;
      document.getElementById('statFiveStar').innerText = d.five_star_reviews;
    }
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

// ==================== TOAST NOTIFICATIONS ====================
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  const bgClass = type === 'success' ? 'bg-emerald-600 border-emerald-400' : (type === 'error' ? 'bg-rose-600 border-rose-400' : 'bg-slate-800 border-slate-700');

  toast.className = `${bgClass} text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-2xl border flex items-center space-x-2.5 transition-all transform translate-y-2 opacity-0 duration-300`;
  toast.innerHTML = `
    <i class="fa-solid ${type === 'success' ? 'fa-circle-check text-white' : 'fa-bell text-white'}"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.remove('translate-y-2', 'opacity-0');
  }, 10);

  setTimeout(() => {
    toast.classList.add('opacity-0', 'translate-y-2');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
