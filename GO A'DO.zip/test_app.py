import unittest
import json
from app import app, SERVICES

class TestGoAdo(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_services_count_and_items(self):
        res = self.client.get('/api/services')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()['data']
        self.assertEqual(len(data), 14)
        
        required_services = [
            'air_panas', 'angkat_cucian', 'ambil_nasi', 'beli_idam',
            'nitip_makanan', 'tandzif', 'manggil_orang', 'bawa_barang',
            'nitip_barang_bn', 'anti_cepu', 'minjem_baju', 'samina_wa_atona',
            'minta_mie', 'minta_seduhan'
        ]
        service_ids = [s['id'] for s in data]
        for req in required_services:
            self.assertIn(req, service_ids, f"Service {req} should be present in 14 services")

    def test_members_endpoint(self):
        res = self.client.get('/api/members')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()['data']
        self.assertGreater(len(data), 0)

    def test_gacha_roll(self):
        res = self.client.post('/api/gacha/roll', json={'count': 1})
        self.assertEqual(res.status_code, 200)
        json_data = res.get_json()
        self.assertEqual(json_data['status'], 'success')
        self.assertEqual(len(json_data['results']), 1)
        self.assertIn('ado', json_data['results'][0])
        self.assertIn('rarity', json_data['results'][0])

        # Test multi-roll
        res_multi = self.client.post('/api/gacha/roll', json={'count': 5})
        self.assertEqual(res_multi.status_code, 200)
        self.assertEqual(len(res_multi.get_json()['results']), 5)

    def test_orders_and_review_flow(self):
        # 1. Create order
        order_payload = {
            'service_id': 'minta_mie',
            'requester': 'Santri Test (Kamar 99)',
            'notes': 'Indomie goreng ekstra pedas',
            'is_samina': True,
            'is_anti_cepu': True
        }
        res_order = self.client.post('/api/orders', json=order_payload)
        self.assertEqual(res_order.status_code, 200)
        order_data = res_order.get_json()['data']
        order_id = order_data['id']
        self.assertEqual(order_data['service_id'], 'minta_mie')
        self.assertTrue(order_data['is_samina'])
        self.assertTrue(order_data['is_anti_cepu'])

        # 2. Update status to Selesai
        res_status = self.client.post(f'/api/orders/{order_id}/status', json={'status': 'Selesai'})
        self.assertEqual(res_status.status_code, 200)
        self.assertEqual(res_status.get_json()['data']['status'], 'Selesai')

        # 3. Submit 5-star review
        review_payload = {
            'order_id': order_id,
            'member_id': order_data['assigned_to']['id'],
            'service_id': 'minta_mie',
            'rating': 5,
            'user_name': 'Santri Test',
            'comment': 'Mienya mantap lezat barokah bintang 5!',
            'tags': ['Barokah', 'Lezat']
        }
        res_review = self.client.post('/api/reviews', json=review_payload)
        self.assertEqual(res_review.status_code, 200)
        self.assertEqual(res_review.get_json()['data']['rating'], 5)

    def test_stats(self):
        res = self.client.get('/api/stats')
        self.assertEqual(res.status_code, 200)
        stats = res.get_json()['data']
        self.assertIn('total_orders', stats)
        self.assertIn('completed_orders', stats)
        self.assertIn('avg_rating', stats)

if __name__ == '__main__':
    unittest.main()
